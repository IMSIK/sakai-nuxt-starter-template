<script setup>
</script>

<template>
  <div class="layout-footer">
    <span class="font-medium ml-2">Sakai Nuxt Starter</span>
  </div>
</template>
