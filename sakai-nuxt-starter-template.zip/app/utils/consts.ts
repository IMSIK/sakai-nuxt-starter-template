export const home = { icon: 'pi pi-home', route: '/' }
